from django.contrib import admin
from .models import tour
# Register your models here.
admin.site.register(tour)